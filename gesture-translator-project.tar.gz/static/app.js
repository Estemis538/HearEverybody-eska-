const toggleBtn = document.getElementById("toggleBtn");
const statusEl = document.getElementById("status");
const resultEl = document.getElementById("result");
const videoEl = document.getElementById("video");
const canvasEl = document.getElementById("canvas");
const ctx = canvasEl.getContext("2d");

let stream = null;
let timerId = null;
let inFlight = false;

async function sendFrame() {
  if (!stream || inFlight) return;
  inFlight = true;
  try {
    // Рисуем текущий кадр видео в canvas, кодируем в JPEG и отправляем на Python.
    ctx.drawImage(videoEl, 0, 0, canvasEl.width, canvasEl.height);
    const dataUrl = canvasEl.toDataURL("image/jpeg", 0.6); // media type + base64

    const resp = await fetch("/api/recognize", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ frame: dataUrl }),
    });

    const json = await resp.json();
    resultEl.value = json.word || "";
    statusEl.textContent = json.word ? `Распознано: ${json.word}` : "";
  } catch (err) {
    statusEl.textContent = "Ошибка соединения / распознавания";
  } finally {
    inFlight = false;
  }
}

async function startCamera() {
  try {
    stream = await navigator.mediaDevices.getUserMedia({
      video: { facingMode: "user" },
      audio: false,
    });
    videoEl.srcObject = stream;
    await videoEl.play();

    statusEl.textContent = "Камера включена. Покажите одну из 20 поз.";
    timerId = setInterval(sendFrame, 250); // ~4 кадра/сек, чтобы не перегружать сеть/CPU
    toggleBtn.textContent = "Выключить камеру";
  } catch (err) {
    statusEl.textContent =
      "Не удалось получить доступ к камере. Проверьте разрешения браузера.";
  }
}

function stopCamera() {
  if (timerId) clearInterval(timerId);
  timerId = null;
  inFlight = false;

  if (stream) {
    stream.getTracks().forEach((t) => t.stop());
  }
  stream = null;

  toggleBtn.textContent = "Включить камеру";
  statusEl.textContent = "Камера выключена";
  resultEl.value = "";
}

toggleBtn.addEventListener("click", async () => {
  if (stream) stopCamera();
  else await startCamera();
});

